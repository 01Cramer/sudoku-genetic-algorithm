
import sys
from cpuinfo.cpuinfo import *


