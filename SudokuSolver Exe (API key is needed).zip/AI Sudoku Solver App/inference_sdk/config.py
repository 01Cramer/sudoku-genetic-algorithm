class InferenceSDKDeprecationWarning(Warning):
    pass
